# validation.php
Laravel 5.5 日本語バリデーションメッセージファイル
